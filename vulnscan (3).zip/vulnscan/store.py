"""
store.py — SQLite persistence for the response cache and the scan history.

Two tables, one file. The cache is what keeps the free 500-lookups/day quota
alive when more than one person uses the tool; the history is what makes the
results revisitable.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from typing import Any, Optional

DB_PATH = os.environ.get("DB_PATH", os.path.join("data", "scans.db"))
CACHE_TTL_SECONDS = int(os.environ.get("CACHE_TTL_SECONDS", 6 * 60 * 60))

_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS cache (
    key        TEXT PRIMARY KEY,
    payload    TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,
    target      TEXT NOT NULL,
    verdict     TEXT NOT NULL,
    detections  INTEGER NOT NULL DEFAULT 0,
    engines     INTEGER NOT NULL DEFAULT 0,
    payload     TEXT NOT NULL,
    created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_history_created ON history(created_at DESC);
"""


def _connect() -> sqlite3.Connection:
    directory = os.path.dirname(DB_PATH)
    if directory:
        os.makedirs(directory, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with _lock, _connect() as conn:
        conn.executescript(SCHEMA)


# -- cache -----------------------------------------------------------------


def cache_get(key: str) -> Optional[dict]:
    try:
        with _lock, _connect() as conn:
            row = conn.execute(
                "SELECT payload, created_at FROM cache WHERE key = ?", (key,)
            ).fetchone()
    except sqlite3.Error:
        return None
    if not row:
        return None
    if time.time() - row["created_at"] > CACHE_TTL_SECONDS:
        return None
    try:
        payload = json.loads(row["payload"])
    except ValueError:
        return None
    payload["cached"] = True
    payload["cached_age_seconds"] = int(time.time() - row["created_at"])
    return payload


def cache_put(key: str, payload: dict) -> None:
    try:
        with _lock, _connect() as conn:
            conn.execute(
                "INSERT INTO cache(key, payload, created_at) VALUES (?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET payload=excluded.payload, "
                "created_at=excluded.created_at",
                (key, json.dumps(payload), int(time.time())),
            )
    except sqlite3.Error:
        pass  # A cache miss is never fatal.


# -- history ---------------------------------------------------------------


def history_add(report: dict) -> None:
    verdict = report.get("verdict", {}) or {}
    try:
        with _lock, _connect() as conn:
            conn.execute(
                "INSERT INTO history(kind, target, verdict, detections, engines, "
                "payload, created_at) VALUES (?,?,?,?,?,?,?)",
                (
                    report.get("kind", "?"),
                    report.get("target", "?"),
                    verdict.get("level", "unknown"),
                    int(verdict.get("detections", 0) or 0),
                    int(verdict.get("engines", 0) or 0),
                    json.dumps(report),
                    int(time.time()),
                ),
            )
            conn.execute(
                "DELETE FROM history WHERE id NOT IN "
                "(SELECT id FROM history ORDER BY created_at DESC LIMIT 500)"
            )
    except sqlite3.Error:
        pass


def history_list(limit: int = 50) -> list[dict[str, Any]]:
    try:
        with _lock, _connect() as conn:
            rows = conn.execute(
                "SELECT id, kind, target, verdict, detections, engines, created_at "
                "FROM history ORDER BY created_at DESC LIMIT ?",
                (max(1, min(limit, 200)),),
            ).fetchall()
    except sqlite3.Error:
        return []
    return [dict(r) for r in rows]


def history_get(item_id: int) -> Optional[dict]:
    try:
        with _lock, _connect() as conn:
            row = conn.execute(
                "SELECT payload FROM history WHERE id = ?", (item_id,)
            ).fetchone()
    except sqlite3.Error:
        return None
    if not row:
        return None
    try:
        return json.loads(row["payload"])
    except ValueError:
        return None
