/* VulnScan frontend.
 *
 * Talks only to this app's own /api/* routes. The VirusTotal key lives on the
 * server and is never present in anything this file can see.
 */
(function () {
  "use strict";

  // ---------------------------------------------------------------- helpers

  const $ = (sel) => document.querySelector(sel);

  /* Everything rendered into innerHTML goes through this. Engine names and
     detection strings come from third parties, so they are untrusted input. */
  function esc(value) {
    if (value === null || value === undefined) return "";
    return String(value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function fmtBytes(n) {
    if (typeof n !== "number" || !isFinite(n)) return "—";
    const units = ["B", "KB", "MB", "GB"];
    let i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i += 1; }
    return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
  }

  function fmtDate(epochSeconds) {
    if (!epochSeconds) return "—";
    return new Date(epochSeconds * 1000).toLocaleString();
  }

  function fmtAge(seconds) {
    if (seconds < 60) return "just now";
    if (seconds < 3600) return `${Math.round(seconds / 60)} min ago`;
    if (seconds < 86400) return `${Math.round(seconds / 3600)} h ago`;
    return `${Math.round(seconds / 86400)} d ago`;
  }

  async function api(path, options) {
    const res = await fetch(path, options);
    let body;
    try {
      body = await res.json();
    } catch (_) {
      throw new Error(`The server returned an unreadable response (HTTP ${res.status}).`);
    }
    if (!res.ok || body.ok === false) {
      const err = new Error(body.error || `Request failed (HTTP ${res.status}).`);
      err.notFound = Boolean(body.not_found);
      err.retryAfter = body.retry_after || 0;
      throw err;
    }
    return body;
  }

  // ---------------------------------------------------------------- status

  const statusArea = $("#statusArea");
  const statusAlert = $("#statusAlert");
  const statusText = $("#statusText");
  const statusSpinner = $("#statusSpinner");

  function showStatus(message, variant, busy) {
    statusArea.hidden = false;
    statusAlert.className = `alert d-flex align-items-center gap-3 mb-0 alert-${variant || "info"}`;
    statusText.textContent = message;
    statusSpinner.hidden = !busy;
  }

  function hideStatus() { statusArea.hidden = true; }

  function setBusy(isBusy) {
    document.querySelectorAll("#scanTabs button, form button[type=submit]")
      .forEach((el) => { el.disabled = isBusy; });
    if (!isBusy && !selectedFile) $("#fileSubmit").disabled = true;
  }

  // ---------------------------------------------------------------- render

  const results = $("#results");

  const LEVEL_META = {
    malicious: { icon: "bi-exclamation-octagon-fill", alert: "danger",
                 blurb: "One or more security vendors flagged this as malicious." },
    suspicious: { icon: "bi-exclamation-triangle-fill", alert: "warning",
                  blurb: "At least one vendor considers this suspicious." },
    clean: { icon: "bi-check-circle-fill", alert: "success",
             blurb: "No security vendor flagged this. That is a good sign, not a guarantee." },
    unknown: { icon: "bi-question-circle-fill", alert: "secondary",
               blurb: "No engines have reported on this yet." }
  };

  const KIND_LABEL = { url: "URL", file: "File", ip: "IP address", domain: "Domain" };

  function metaRows(report) {
    const m = report.meta || {};
    const rows = [];
    const add = (label, value) => {
      if (value === null || value === undefined || value === "" ) return;
      rows.push([label, value]);
    };

    if (report.kind === "url") {
      add("Final URL", m.final_url);
      add("Page title", m.title);
      add("Times submitted", m.times_submitted);
      add("Last analysed", m.last_analysis_date ? fmtDate(m.last_analysis_date) : null);
    } else if (report.kind === "file") {
      add("File name", m.submitted_name || m.meaningful_name || (m.names || [])[0]);
      add("Type", m.type_description);
      add("Size", typeof m.size === "number" ? fmtBytes(m.size) : null);
      add("SHA-256", m.sha256);
      add("SHA-1", m.sha1);
      add("MD5", m.md5);
      add("First seen", m.first_submission_date ? fmtDate(m.first_submission_date) : null);
    } else if (report.kind === "ip") {
      add("Network owner", m.as_owner);
      add("ASN", m.asn);
      add("Country", m.country);
      add("Network", m.network);
      add("Registry", m.rir);
    } else if (report.kind === "domain") {
      add("Registrar", m.registrar);
      add("Created", m.creation_date ? fmtDate(m.creation_date) : null);
      if (Array.isArray(m.dns) && m.dns.length) {
        add("DNS records", m.dns.map((r) => `${r.type} → ${r.value}`).join("  ·  "));
      }
    }

    if (typeof m.reputation === "number") add("Community reputation", m.reputation);
    if (m.categories && Object.keys(m.categories).length) {
      add("Categories", Object.values(m.categories).slice(0, 4).join(", "));
    }
    return rows;
  }

  function renderReport(report) {
    const v = report.verdict || {};
    const level = v.level || "unknown";
    const look = LEVEL_META[level] || LEVEL_META.unknown;
    const s = report.stats || {};

    const badges = [];
    if (report.cached) {
      badges.push(`<span class="badge text-bg-secondary" title="Served from this server's cache">
        <i class="bi bi-lightning-charge-fill"></i> cached ${esc(fmtAge(report.cached_age_seconds || 0))}</span>`);
    }
    if (report.from_history) {
      badges.push('<span class="badge text-bg-secondary"><i class="bi bi-clock-history"></i> from history</span>');
    }

    const rows = metaRows(report).map(([label, value]) => `
      <tr>
        <th scope="row" class="text-body-secondary fw-normal small" style="width:11rem">${esc(label)}</th>
        <td class="target-text small">${esc(value)}</td>
      </tr>`).join("");

    const tiles = [
      ["Malicious", s.malicious || 0, "text-danger"],
      ["Suspicious", s.suspicious || 0, "text-warning"],
      ["Harmless", s.harmless || 0, "text-success"],
      ["Undetected", s.undetected || 0, "text-body-secondary"],
      ["Timeout", s.timeout || 0, "text-body-secondary"]
    ].map(([label, num, cls]) => `
      <div class="col">
        <div class="stat-tile h-100">
          <div class="stat-num ${cls}">${esc(num)}</div>
          <div class="stat-label text-body-secondary">${esc(label)}</div>
        </div>
      </div>`).join("");

    const vendors = (report.vendors || []).map((vend) => {
      const cat = vend.category || "undetected";
      const rowCls = cat === "malicious" ? "flagged" : (cat === "suspicious" ? "warned" : "");
      const badgeCls = { malicious: "text-bg-danger", suspicious: "text-bg-warning",
                         harmless: "text-bg-success", undetected: "text-bg-secondary",
                         timeout: "text-bg-secondary" }[cat] || "text-bg-secondary";
      return `<tr class="${rowCls}" data-category="${esc(cat)}" data-engine="${esc((vend.engine || "").toLowerCase())}">
        <td class="fw-medium">${esc(vend.engine)}</td>
        <td><span class="badge ${badgeCls}">${esc(cat)}</span></td>
        <td class="text-body-secondary small">${esc(vend.result || "—")}</td>
      </tr>`;
    }).join("");

    results.hidden = false;
    results.innerHTML = `
      <div class="card shadow-sm border-0 mx-auto scan-card">
        <div class="card-body p-3 p-lg-4">

          <div class="d-flex flex-column flex-sm-row align-items-center gap-4">
            <div class="verdict-ring level-${esc(level)}">
              <div class="text-center">
                <div class="ratio-top">${esc((v.detections !== undefined) ? v.detections : "?")}</div>
                <div class="ratio-bottom">/ ${esc(v.engines || 0)}</div>
              </div>
            </div>
            <div class="flex-grow-1 text-center text-sm-start">
              <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-sm-start gap-2 mb-1">
                <span class="badge text-bg-primary">${esc(KIND_LABEL[report.kind] || report.kind)}</span>
                ${badges.join(" ")}
              </div>
              <h2 class="h5 mb-1 level-${esc(level)}">
                <i class="bi ${esc(look.icon)}"></i> ${esc(v.label || "No verdict")}
              </h2>
              <p class="small text-body-secondary mb-2">${esc(look.blurb)}</p>
              <p class="target-text font-monospace small mb-0">${esc(report.target)}</p>
            </div>
          </div>

          <div class="row row-cols-2 row-cols-md-5 g-2 mt-4">${tiles}</div>

          ${rows ? `<div class="table-responsive mt-4">
            <table class="table table-sm mb-0"><tbody>${rows}</tbody></table>
          </div>` : ""}

          <div class="d-flex flex-wrap gap-2 mt-4">
            <a class="btn btn-sm btn-outline-primary" href="${esc(report.permalink)}"
               target="_blank" rel="noopener noreferrer">
              <i class="bi bi-box-arrow-up-right"></i> Open on VirusTotal
            </a>
            <button class="btn btn-sm btn-outline-secondary" id="copyJson" type="button">
              <i class="bi bi-clipboard"></i> Copy JSON
            </button>
          </div>
        </div>

        ${vendors ? `
        <div class="card-footer bg-body-tertiary border-0 p-3 p-lg-4">
          <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
            <h3 class="h6 mb-0 me-auto">Security vendor analysis
              <span class="text-body-secondary fw-normal">(${esc((report.vendors || []).length)})</span></h3>
            <div class="btn-group btn-group-sm" role="group" aria-label="Filter vendors">
              <button class="btn btn-outline-secondary active" data-filter="all" type="button">All</button>
              <button class="btn btn-outline-secondary" data-filter="flagged" type="button">Flagged only</button>
            </div>
            <input type="search" class="form-control form-control-sm" id="vendorSearch"
                   placeholder="Filter engine…" style="max-width:12rem" aria-label="Filter by engine name">
          </div>
          <div class="table-scroll border rounded">
            <table class="table table-sm table-hover vendor-table mb-0">
              <thead class="sticky-top bg-body-tertiary">
                <tr><th scope="col">Engine</th><th scope="col">Verdict</th><th scope="col">Detection</th></tr>
              </thead>
              <tbody>${vendors}</tbody>
            </table>
          </div>
        </div>` : ""}
      </div>`;

    wireResultControls(report);
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function wireResultControls(report) {
    const copyBtn = $("#copyJson");
    if (copyBtn) {
      copyBtn.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(JSON.stringify(report, null, 2));
          copyBtn.innerHTML = '<i class="bi bi-check2"></i> Copied';
          setTimeout(() => { copyBtn.innerHTML = '<i class="bi bi-clipboard"></i> Copy JSON'; }, 1600);
        } catch (_) {
          copyBtn.textContent = "Copy blocked by browser";
        }
      });
    }

    const search = $("#vendorSearch");
    const rows = Array.from(results.querySelectorAll(".vendor-table tbody tr"));
    let mode = "all";

    function applyFilter() {
      const term = (search && search.value || "").trim().toLowerCase();
      rows.forEach((row) => {
        const cat = row.dataset.category;
        const okMode = mode === "all" || cat === "malicious" || cat === "suspicious";
        const okTerm = !term || row.dataset.engine.includes(term);
        row.hidden = !(okMode && okTerm);
      });
    }

    results.querySelectorAll("[data-filter]").forEach((btn) => {
      btn.addEventListener("click", () => {
        results.querySelectorAll("[data-filter]").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        mode = btn.dataset.filter;
        applyFilter();
      });
    });
    if (search) search.addEventListener("input", applyFilter);
  }

  // ---------------------------------------------------------------- polling

  /* The free VirusTotal tier allows four requests per minute, so polling is
     deliberately slow. Sixteen seconds between attempts, ten attempts max. */
  const POLL_INTERVAL_MS = 16000;
  const POLL_MAX_ATTEMPTS = 10;

  function pollAnalysis(analysisId, kind, target) {
    let attempt = 0;

    const tick = async () => {
      attempt += 1;
      const elapsed = Math.round((attempt * POLL_INTERVAL_MS) / 1000);
      showStatus(
        `Analysis in progress — checking again in ${POLL_INTERVAL_MS / 1000}s (${elapsed}s elapsed).`,
        "info", true
      );
      try {
        const qs = new URLSearchParams({ kind: kind, target: target || "" });
        const body = await api(`/api/analysis/${encodeURIComponent(analysisId)}?${qs}`);
        if (body.queued) {
          if (attempt >= POLL_MAX_ATTEMPTS) {
            showStatus(
              "VirusTotal is still working. It can take a few minutes for a brand-new "
              + "submission — try the same scan again shortly.", "warning", false);
            setBusy(false);
            return;
          }
          setTimeout(tick, POLL_INTERVAL_MS);
          return;
        }
        hideStatus();
        setBusy(false);
        renderReport(body);
        loadHistory();
      } catch (err) {
        if (attempt < POLL_MAX_ATTEMPTS) {
          setTimeout(tick, POLL_INTERVAL_MS);
          return;
        }
        showStatus(err.message, "danger", false);
        setBusy(false);
      }
    };

    setTimeout(tick, 4000);
  }

  async function runScan(fn, workingMessage) {
    results.hidden = true;
    setBusy(true);
    showStatus(workingMessage, "info", true);
    try {
      const body = await fn();
      if (body.queued) {
        showStatus(body.message || "Submitted. Waiting for results…", "info", true);
        pollAnalysis(body.analysis_id, body.kind, body.target);
        return;
      }
      hideStatus();
      setBusy(false);
      renderReport(body);
      loadHistory();
    } catch (err) {
      const extra = err.retryAfter ? ` Try again in about ${err.retryAfter}s.` : "";
      showStatus(err.message + extra, err.notFound ? "warning" : "danger", false);
      setBusy(false);
    }
  }

  const jsonPost = (path, payload) => api(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  // ---------------------------------------------------------------- forms

  $("#formUrl").addEventListener("submit", (e) => {
    e.preventDefault();
    const url = $("#inputUrl").value.trim();
    if (!url) return;
    runScan(
      () => jsonPost("/api/scan/url", { url: url, rescan: $("#forceRescan").checked }),
      "Checking that URL against VirusTotal…"
    );
  });

  $("#formIp").addEventListener("submit", (e) => {
    e.preventDefault();
    const value = $("#inputIp").value.trim();
    if (!value) return;
    runScan(() => jsonPost("/api/lookup", { kind: "ip", value: value }),
      "Looking up that IP address…");
  });

  $("#formDomain").addEventListener("submit", (e) => {
    e.preventDefault();
    const value = $("#inputDomain").value.trim().replace(/^https?:\/\//i, "").split("/")[0];
    if (!value) return;
    $("#inputDomain").value = value;
    runScan(() => jsonPost("/api/lookup", { kind: "domain", value: value }),
      "Looking up that domain…");
  });

  $("#formHash").addEventListener("submit", (e) => {
    e.preventDefault();
    const value = $("#inputHash").value.trim();
    if (!value) return;
    runScan(() => jsonPost("/api/lookup", { kind: "hash", value: value }),
      "Looking up that file hash…");
  });

  // ---------------------------------------------------------------- file tab

  const MAX_BYTES = 32 * 1024 * 1024;
  const dropzone = $("#dropzone");
  const fileInput = $("#inputFile");
  const dropzoneText = $("#dropzoneText");
  const fileSubmit = $("#fileSubmit");
  let selectedFile = null;

  function chooseFile(file) {
    if (!file) return;
    if (file.size > MAX_BYTES) {
      showStatus(`"${file.name}" is ${fmtBytes(file.size)} — over the 32 MB limit.`, "danger", false);
      return;
    }
    selectedFile = file;
    dropzone.classList.add("has-file");
    dropzoneText.textContent = `${file.name} (${fmtBytes(file.size)})`;
    fileSubmit.disabled = false;
    hideStatus();
  }

  dropzone.addEventListener("click", () => fileInput.click());
  dropzone.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fileInput.click(); }
  });
  fileInput.addEventListener("change", () => chooseFile(fileInput.files[0]));

  ["dragenter", "dragover"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault(); dropzone.classList.add("is-dragging");
    }));
  ["dragleave", "drop"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault(); dropzone.classList.remove("is-dragging");
    }));
  dropzone.addEventListener("drop", (e) => {
    if (e.dataTransfer && e.dataTransfer.files.length) chooseFile(e.dataTransfer.files[0]);
  });

  $("#formFile").addEventListener("submit", (e) => {
    e.preventDefault();
    if (!selectedFile) return;
    const data = new FormData();
    data.append("file", selectedFile, selectedFile.name);
    runScan(
      () => api("/api/scan/file", { method: "POST", body: data }),
      `Hashing and checking "${selectedFile.name}"…`
    );
  });

  // ---------------------------------------------------------------- history

  const historyBody = $("#historyBody");

  async function loadHistory() {
    try {
      const body = await api("/api/history");
      if (!body.items.length) {
        historyBody.innerHTML =
          '<p class="text-body-secondary p-3 mb-0">No scans recorded yet.</p>';
        return;
      }
      historyBody.innerHTML = body.items.map((item) => `
        <button class="history-item" type="button" data-id="${esc(item.id)}">
          <div class="d-flex align-items-center gap-2">
            <span class="dot dot-${esc(item.verdict)}"></span>
            <span class="badge text-bg-secondary">${esc(KIND_LABEL[item.kind] || item.kind)}</span>
            <span class="ms-auto small text-body-secondary">${esc(item.detections)}/${esc(item.engines)}</span>
          </div>
          <div class="target-text small mt-1 font-monospace">${esc(item.target)}</div>
          <div class="small text-body-secondary">${esc(fmtDate(item.created_at))}</div>
        </button>`).join("");

      historyBody.querySelectorAll(".history-item").forEach((btn) => {
        btn.addEventListener("click", async () => {
          try {
            const report = await api(`/api/history/${btn.dataset.id}`);
            const panel = bootstrap.Offcanvas.getInstance($("#historyPanel"));
            if (panel) panel.hide();
            hideStatus();
            renderReport(report);
          } catch (err) {
            showStatus(err.message, "danger", false);
          }
        });
      });
    } catch (_) {
      historyBody.innerHTML =
        '<p class="text-body-secondary p-3 mb-0">History is unavailable.</p>';
    }
  }

  $("#historyBtn").addEventListener("click", loadHistory);

  // ---------------------------------------------------------------- theme

  const themeBtn = $("#themeBtn");

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-bs-theme", theme);
    themeBtn.innerHTML = theme === "dark"
      ? '<i class="bi bi-sun-fill"></i>'
      : '<i class="bi bi-moon-stars-fill"></i>';
    try { localStorage.setItem("vulnscan-theme", theme); } catch (_) { /* private mode */ }
  }

  let startTheme = "dark";
  try { startTheme = localStorage.getItem("vulnscan-theme") || "dark"; } catch (_) { /* noop */ }
  applyTheme(startTheme);

  themeBtn.addEventListener("click", () => {
    const now = document.documentElement.getAttribute("data-bs-theme");
    applyTheme(now === "dark" ? "light" : "dark");
  });

  loadHistory();
})();
