"""
End-to-end tests against Flask's test client with VirusTotal mocked out.

Run:  python -m pytest tests -q      (or)   python tests/test_app.py
"""

import base64
import io
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ["VT_API_KEY"] = "test-key-not-real"
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ["VISITOR_LIMIT_PER_WINDOW"] = "10000"

import app as application  # noqa: E402
import vt_client  # noqa: E402

PASS, FAIL = [], []


def check(name, condition, detail=""):
    (PASS if condition else FAIL).append(name)
    print(("  PASS  " if condition else "  FAIL  ") + name + (f"  — {detail}" if detail and not condition else ""))


# ---------------------------------------------------------------- fixtures

ANALYSIS_RESULTS = {
    "Kaspersky": {"category": "malicious", "engine_name": "Kaspersky", "result": "Trojan.Win32.Test"},
    "BitDefender": {"category": "malicious", "engine_name": "BitDefender", "result": "EICAR-Test-File"},
    "Sophos": {"category": "suspicious", "engine_name": "Sophos", "result": "Heuristic"},
    "Avast": {"category": "undetected", "engine_name": "Avast", "result": None},
    "ClamAV": {"category": "harmless", "engine_name": "ClamAV", "result": None},
}

URL_REPORT = {"data": {"type": "url", "id": "abc", "attributes": {
    "last_analysis_stats": {"malicious": 2, "suspicious": 1, "harmless": 1, "undetected": 1, "timeout": 0},
    "last_analysis_results": ANALYSIS_RESULTS,
    "last_final_url": "https://example.com/",
    "title": "Example <script>alert(1)</script>",
    "reputation": -14, "times_submitted": 9,
}}}

CLEAN_IP_REPORT = {"data": {"type": "ip_address", "id": "8.8.8.8", "attributes": {
    "last_analysis_stats": {"malicious": 0, "suspicious": 0, "harmless": 60, "undetected": 34, "timeout": 0},
    "last_analysis_results": {"Google Safebrowsing": {"category": "harmless", "engine_name": "Google Safebrowsing", "result": "clean"}},
    "as_owner": "GOOGLE", "asn": 15169, "country": "US", "network": "8.8.8.0/24", "reputation": 0,
}}}

FILE_REPORT = {"data": {"type": "file", "id": "x", "attributes": {
    "last_analysis_stats": {"malicious": 63, "suspicious": 0, "harmless": 0, "undetected": 3, "timeout": 0},
    "last_analysis_results": ANALYSIS_RESULTS,
    "sha256": "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f",
    "md5": "44d88612fea8a8f36de82e1278abb02f", "sha1": "3395856ce81f2b7382dee72602f798b642f14140",
    "size": 68, "type_description": "Text", "names": ["eicar.com"], "first_submission_date": 1000000000,
}}}

QUEUED_ANALYSIS = {"data": {"type": "analysis", "id": "q1", "attributes": {"status": "queued", "stats": {}, "results": {}}}}

DONE_ANALYSIS = {"data": {"type": "analysis", "id": "q1", "attributes": {
    "status": "completed",
    "stats": {"malicious": 2, "suspicious": 1, "harmless": 1, "undetected": 1, "timeout": 0},
    "results": ANALYSIS_RESULTS,
}}, "meta": {"url_info": {"url": "https://fresh.example.com/"}}}


class FakeVT(vt_client.VirusTotalClient):
    """Replaces every network call with a scripted response."""

    def __init__(self):
        self.calls = []
        self.api_key = "test-key-not-real"
        self.url_known = True
        self.file_known = True
        self.analysis_done = False
        self.limiter = vt_client.RateLimiter(per_minute=10000)

    @property
    def configured(self):
        return True

    def get_url_report(self, url):
        self.calls.append(("get_url", url))
        return URL_REPORT if self.url_known else None

    def get_file_report(self, h):
        self.calls.append(("get_file", h))
        return FILE_REPORT if self.file_known else None

    def get_ip_report(self, ip):
        self.calls.append(("get_ip", ip))
        return CLEAN_IP_REPORT

    def get_domain_report(self, d):
        self.calls.append(("get_domain", d))
        return {"data": {"type": "domain", "id": d, "attributes": {
            "last_analysis_stats": {"malicious": 0, "suspicious": 0, "harmless": 70, "undetected": 24, "timeout": 0},
            "last_analysis_results": {}, "registrar": "MarkMonitor", "creation_date": 874306800,
            "last_dns_records": [{"type": "A", "value": "93.184.216.34"}], "reputation": 5}}}

    def get_analysis(self, aid):
        self.calls.append(("get_analysis", aid))
        return DONE_ANALYSIS if self.analysis_done else QUEUED_ANALYSIS

    def submit_url(self, url):
        self.calls.append(("submit_url", url))
        return "u-analysis-1"

    def submit_file(self, name, content):
        self.calls.append(("submit_file", name))
        return "f-analysis-1"


fake = FakeVT()
application.vt = fake
client = application.app.test_client()


def fresh_cache():
    """Wipe the cache so a test actually hits the (fake) API."""
    import store
    import sqlite3
    try:
        with sqlite3._original_connect(store.DB_PATH) if False else store._connect() as conn:
            conn.execute("DELETE FROM cache")
    except Exception:
        pass


# ---------------------------------------------------------------- tests

print("\n--- pure functions ---")
check("url_identifier matches VirusTotal's urlsafe-base64-no-padding scheme",
      vt_client.url_identifier("https://example.com") ==
      base64.urlsafe_b64encode(b"https://example.com").decode().rstrip("="))
check("url_identifier is URL-safe for URLs producing +/ in standard base64",
      "+" not in vt_client.url_identifier("https://a.example.com/?q=ÿþ")
      and "/" not in vt_client.url_identifier("https://a.example.com/?q=ÿþ"))
check("valid_url accepts https", vt_client.valid_url("https://example.com"))
check("valid_url rejects javascript: scheme", not vt_client.valid_url("javascript:alert(1)"))
check("valid_url rejects bare text", not vt_client.valid_url("not a url"))
check("valid_ip accepts IPv4", vt_client.valid_ip("8.8.8.8"))
check("valid_ip accepts IPv6", vt_client.valid_ip("2001:4860:4860::8888"))
check("valid_ip rejects 999.1.1.1", not vt_client.valid_ip("999.1.1.1"))
check("valid_domain accepts example.com", vt_client.valid_domain("example.com"))
check("valid_domain rejects a bare label", not vt_client.valid_domain("localhost"))
check("valid_hash accepts md5/sha1/sha256",
      vt_client.valid_hash("44d88612fea8a8f36de82e1278abb02f")
      and vt_client.valid_hash("3395856ce81f2b7382dee72602f798b642f14140")
      and vt_client.valid_hash("275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"))
check("valid_hash rejects wrong length", not vt_client.valid_hash("deadbeef"))

norm = vt_client.normalize("url", "https://example.com", URL_REPORT)
check("normalize computes malicious verdict", norm["verdict"]["level"] == "malicious", norm["verdict"])
check("normalize computes 3/5 score", norm["verdict"]["score"] == "3/5", norm["verdict"]["score"])
check("normalize sorts flagged vendors first",
      norm["vendors"][0]["category"] == "malicious" and norm["vendors"][-1]["category"] in ("harmless", "undetected"))
clean = vt_client.normalize("ip", "8.8.8.8", CLEAN_IP_REPORT)
check("normalize computes clean verdict", clean["verdict"]["level"] == "clean")

print("\n--- pages ---")
r = client.get("/")
check("GET / returns 200", r.status_code == 200)
body = r.get_data(as_text=True)
check("API key is NOT present in the served HTML", "test-key-not-real" not in body)
check("HTML loads Bootstrap", "vendor/bootstrap.min.css" in body)
check("GET /health reports key configured", client.get("/health").get_json()["key_configured"] is True)

print("\n--- validation (rejected before any network call) ---")
before = len(fake.calls)
check("bad URL -> 400", client.post("/api/scan/url", json={"url": "javascript:alert(1)"}).status_code == 400)
check("bad IP -> 400", client.post("/api/lookup", json={"kind": "ip", "value": "999.1.1.1"}).status_code == 400)
check("bad domain -> 400", client.post("/api/lookup", json={"kind": "domain", "value": "!!"}).status_code == 400)
check("bad hash -> 400", client.post("/api/lookup", json={"kind": "hash", "value": "xyz"}).status_code == 400)
check("unknown kind -> 400", client.post("/api/lookup", json={"kind": "wat", "value": "a"}).status_code == 400)
check("no VirusTotal calls made for invalid input", len(fake.calls) == before)

print("\n--- URL scan ---")
r = client.post("/api/scan/url", json={"url": "https://example.com"})
d = r.get_json()
check("URL scan returns 200", r.status_code == 200)
check("URL scan returns the cached-report path (1 GET, no POST)", ("get_url", "https://example.com") in fake.calls)
check("URL scan verdict is malicious", d["verdict"]["level"] == "malicious")
check("URL scan returns 5 vendors", len(d["vendors"]) == 5)
check("URL permalink points at VirusTotal GUI", d["permalink"].startswith("https://www.virustotal.com/gui/url/"))

r2 = client.post("/api/scan/url", json={"url": "https://example.com"})
check("second identical URL scan is served from cache", r2.get_json().get("cached") is True)

r3 = client.post("/api/scan/url", json={"url": "example.com/no-scheme"})
check("bare domain input is auto-prefixed with http://", r3.status_code == 200)

fake.url_known = False
r4 = client.post("/api/scan/url", json={"url": "https://brand-new-site.example/", "rescan": True})
d4 = r4.get_json()
check("unknown URL is submitted for analysis", d4.get("queued") is True and d4.get("analysis_id") == "u-analysis-1")
fake.url_known = True

print("\n--- analysis polling ---")
fake.analysis_done = False
d5 = client.get("/api/analysis/u-analysis-1?kind=url").get_json()
check("in-flight analysis reports queued", d5.get("queued") is True and d5.get("status") == "queued")
fake.analysis_done = True
d6 = client.get("/api/analysis/u-analysis-1?kind=url").get_json()
check("completed analysis returns a full report", d6.get("queued") is None and d6["verdict"]["level"] == "malicious")
check("completed analysis resolves its target from VT meta",
      d6["target"] == "https://fresh.example.com/", d6["target"])

print("\n--- IP / domain / hash lookups ---")
d = client.post("/api/lookup", json={"kind": "ip", "value": "8.8.8.8"}).get_json()
check("IP lookup is clean", d["verdict"]["level"] == "clean")
check("IP lookup carries network owner", d["meta"]["as_owner"] == "GOOGLE")

d = client.post("/api/lookup", json={"kind": "domain", "value": "example.com"}).get_json()
check("domain lookup returns registrar", d["meta"]["registrar"] == "MarkMonitor")
check("domain lookup returns DNS records", d["meta"]["dns"][0]["value"] == "93.184.216.34")

d = client.post("/api/lookup", json={"kind": "hash", "value": "44D88612FEA8A8F36DE82E1278ABB02F"}).get_json()
check("hash lookup is case-insensitive and works", d["verdict"]["detections"] == 63)
check("hash lookup is normalised to a file report", d["kind"] == "file")

fake.file_known = False
r = client.post("/api/lookup", json={"kind": "hash", "value": "0" * 64})
check("unknown hash returns 404 with not_found", r.status_code == 404 and r.get_json()["not_found"] is True)
fake.file_known = True

print("\n--- file upload ---")
eicar = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
r = client.post("/api/scan/file", data={"file": (io.BytesIO(eicar), "eicar.com")},
                content_type="multipart/form-data")
d = r.get_json()
expected_sha = vt_client.sha256_of(eicar)
check("file upload returns 200", r.status_code == 200)
check("file is hashed locally and looked up by SHA-256 before uploading",
      ("get_file", expected_sha) in fake.calls)
check("known file returns a report without being uploaded",
      not any(c[0] == "submit_file" for c in fake.calls))
check("file report shows 63 detections", d["verdict"]["detections"] == 63)

fake.file_known = False
r = client.post("/api/scan/file", data={"file": (io.BytesIO(b"totally novel bytes"), "new.bin")},
                content_type="multipart/form-data")
check("unknown file is uploaded for analysis", r.get_json().get("analysis_id") == "f-analysis-1")
check("submit_file was called", any(c[0] == "submit_file" for c in fake.calls))
fake.file_known = True

r = client.post("/api/scan/file", data={"file": (io.BytesIO(b""), "empty.txt")},
                content_type="multipart/form-data")
check("empty file -> 400", r.status_code == 400)
check("missing file -> 400", client.post("/api/scan/file", data={}, content_type="multipart/form-data").status_code == 400)

print("\n--- history ---")
h = client.get("/api/history").get_json()
check("history records past scans", len(h["items"]) > 0)
first_id = h["items"][0]["id"]
check("history entry can be reopened", client.get(f"/api/history/{first_id}").get_json()["ok"] is True)
check("unknown history id -> 404", client.get("/api/history/999999").status_code == 404)

print("\n--- error shape ---")
r = client.get("/api/does-not-exist")
check("unknown /api route returns JSON not HTML", r.is_json and r.get_json()["ok"] is False)

print("\n--- rate limiter ---")
rl = vt_client.RateLimiter(per_minute=2, max_wait=0.2)
rl.acquire(); rl.acquire()
try:
    rl.acquire()
    check("rate limiter refuses a 3rd call in the same minute", False, "no exception raised")
except vt_client.VTError as exc:
    check("rate limiter refuses a 3rd call in the same minute", exc.status == 429)

print(f"\n{'=' * 60}\n{len(PASS)} passed, {len(FAIL)} failed")
if FAIL:
    for name in FAIL:
        print("  FAILED:", name)
    sys.exit(1)
print("All checks passed.")
