"""
demo_server.py — run the whole UI with VirusTotal mocked out.

Useful for demoing or developing the interface without spending any of the
500-lookups-a-day free quota, and without needing a network connection.

    python tests/demo_server.py     ->  http://localhost:5001
"""

import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("VT_API_KEY", "demo-key")
os.environ.setdefault("DB_PATH", os.path.join(tempfile.mkdtemp(), "demo.db"))

import test_app  # noqa: E402  (installs the FakeVT client and fixtures)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5001))
    print(f"\nDemo server (VirusTotal mocked) -> http://localhost:{port}\n")
    test_app.application.app.run(host="0.0.0.0", port=port, debug=False)
