"""
vt_client.py — a thin, quota-aware wrapper around the VirusTotal API v3.

Design notes:
  * The API key is read from the environment ONLY. It is never returned to a
    caller and never rendered into a template, so it cannot leak to the browser.
  * The free public key allows ~4 lookups/minute. Every call therefore passes
    through a token bucket, and every successful response is cached, so a busy
    page does not burn the quota.
"""

from __future__ import annotations

import base64
import hashlib
import ipaddress
import os
import re
import threading
import time
from typing import Any, Dict, Optional, Tuple
from urllib.parse import urlparse

import requests

VT_BASE = "https://www.virustotal.com/api/v3"
GUI_BASE = "https://www.virustotal.com/gui"

# 32 MB is the hard limit of the plain POST /files endpoint.
MAX_UPLOAD_BYTES = 32 * 1024 * 1024


class VTError(Exception):
    """Any failure we want to show the user as a clean message."""

    def __init__(self, message: str, status: int = 502, retry_after: int = 0):
        super().__init__(message)
        self.message = message
        self.status = status
        self.retry_after = retry_after


class RateLimiter:
    """Token bucket. Blocks briefly, then refuses rather than hanging a request."""

    def __init__(self, per_minute: int = 4, max_wait: float = 20.0):
        self.per_minute = max(1, per_minute)
        self.max_wait = max_wait
        self._hits: list[float] = []
        self._lock = threading.Lock()

    def acquire(self) -> None:
        deadline = time.time() + self.max_wait
        while True:
            with self._lock:
                now = time.time()
                self._hits = [t for t in self._hits if now - t < 60.0]
                if len(self._hits) < self.per_minute:
                    self._hits.append(now)
                    return
                wait = 60.0 - (now - self._hits[0]) + 0.05
            if time.time() + wait > deadline:
                raise VTError(
                    "The shared VirusTotal quota is saturated right now "
                    f"({self.per_minute} lookups/minute on the free tier). "
                    "Wait a moment and try again.",
                    status=429,
                    retry_after=int(wait) + 1,
                )
            time.sleep(min(wait, 1.0))


# --------------------------------------------------------------------------
# Validation helpers — used by the app layer before anything touches the network
# --------------------------------------------------------------------------

_DOMAIN_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)"
    r"(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))+$"
)
_HASH_RE = re.compile(r"^[A-Fa-f0-9]{32}$|^[A-Fa-f0-9]{40}$|^[A-Fa-f0-9]{64}$")


SCHEME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9+.\-]*:")


def valid_url(value: str) -> bool:
    """Accept only real http(s) URLs with a plausible host.

    Deliberately strict: a permissive check here would let something like
    `http://javascript:alert(1)` through, because urlparse is happy to read
    "javascript" as a hostname and "alert(1)" as a port.
    """
    value = (value or "").strip()
    if not value or any(ch.isspace() for ch in value):
        return False
    try:
        p = urlparse(value)
    except ValueError:
        return False
    if p.scheme not in ("http", "https"):
        return False
    try:
        p.port  # raises ValueError on a non-numeric port
    except ValueError:
        return False
    host = p.hostname
    if not host:
        return False
    # A host must be dotted (example.com) or a bare IP literal (::1, 127.0.0.1).
    return "." in host or valid_ip(host)


def valid_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value.strip())
        return True
    except ValueError:
        return False


def valid_domain(value: str) -> bool:
    return bool(_DOMAIN_RE.match(value.strip()))


def valid_hash(value: str) -> bool:
    return bool(_HASH_RE.match(value.strip()))


def url_identifier(url: str) -> str:
    """VirusTotal identifies a URL by its URL-safe base64, stripped of padding."""
    return base64.urlsafe_b64encode(url.strip().encode("utf-8")).decode("ascii").rstrip("=")


def sha256_of(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# --------------------------------------------------------------------------
# Client
# --------------------------------------------------------------------------


class VirusTotalClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        per_minute: Optional[int] = None,
        timeout: int = 30,
    ):
        self.api_key = api_key or os.environ.get("VT_API_KEY", "")
        self.timeout = timeout
        self.limiter = RateLimiter(
            per_minute=int(per_minute or os.environ.get("VT_RATE_LIMIT_PER_MIN", 4))
        )
        self.session = requests.Session()
        self.session.headers.update(
            {"x-apikey": self.api_key, "Accept": "application/json"}
        )

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    # -- transport ---------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs) -> Tuple[int, Any]:
        if not self.configured:
            raise VTError(
                "No VirusTotal API key is configured on the server. "
                "Set the VT_API_KEY environment variable and restart.",
                status=503,
            )
        self.limiter.acquire()
        url = f"{VT_BASE}{path}"
        try:
            resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        except requests.Timeout:
            raise VTError("VirusTotal did not respond in time. Try again.", status=504)
        except requests.RequestException as exc:
            raise VTError(f"Could not reach VirusTotal: {exc}", status=502)

        if resp.status_code == 404:
            return 404, None
        if resp.status_code == 401:
            raise VTError(
                "VirusTotal rejected the API key (401). It may be wrong or revoked.",
                status=401,
            )
        if resp.status_code == 429:
            raise VTError(
                "VirusTotal rate limit hit (429). The free tier allows 4 lookups per "
                "minute and 500 per day.",
                status=429,
                retry_after=60,
            )
        if resp.status_code >= 400:
            detail = ""
            try:
                detail = resp.json().get("error", {}).get("message", "")
            except ValueError:
                detail = resp.text[:200]
            raise VTError(
                f"VirusTotal returned {resp.status_code}. {detail}".strip(),
                status=resp.status_code if resp.status_code < 500 else 502,
            )
        try:
            return resp.status_code, resp.json()
        except ValueError:
            raise VTError("VirusTotal returned a response that was not JSON.", status=502)

    # -- reads -------------------------------------------------------------

    def get_url_report(self, url: str) -> Optional[dict]:
        _, body = self._request("GET", f"/urls/{url_identifier(url)}")
        return body

    def get_file_report(self, file_hash: str) -> Optional[dict]:
        _, body = self._request("GET", f"/files/{file_hash.strip().lower()}")
        return body

    def get_ip_report(self, ip: str) -> Optional[dict]:
        _, body = self._request("GET", f"/ip_addresses/{ip.strip()}")
        return body

    def get_domain_report(self, domain: str) -> Optional[dict]:
        _, body = self._request("GET", f"/domains/{domain.strip().lower()}")
        return body

    def get_analysis(self, analysis_id: str) -> Optional[dict]:
        _, body = self._request("GET", f"/analyses/{analysis_id}")
        return body

    # -- writes ------------------------------------------------------------

    def submit_url(self, url: str) -> str:
        _, body = self._request(
            "POST",
            "/urls",
            data={"url": url.strip()},
            headers={"content-type": "application/x-www-form-urlencoded"},
        )
        analysis_id = (body or {}).get("data", {}).get("id")
        if not analysis_id:
            raise VTError("VirusTotal accepted the URL but returned no analysis id.")
        return analysis_id

    def submit_file(self, filename: str, content: bytes) -> str:
        if len(content) > MAX_UPLOAD_BYTES:
            raise VTError(
                "That file is larger than 32 MB, which is the limit for direct upload.",
                status=413,
            )
        _, body = self._request(
            "POST", "/files", files={"file": (filename, content)}
        )
        analysis_id = (body or {}).get("data", {}).get("id")
        if not analysis_id:
            raise VTError("VirusTotal accepted the file but returned no analysis id.")
        return analysis_id


# --------------------------------------------------------------------------
# Normalisation — collapse four different VT object shapes into one contract
# --------------------------------------------------------------------------

_SEVERITY_ORDER = {"clean": 0, "unknown": 1, "suspicious": 2, "malicious": 3}


def _verdict(stats: Dict[str, int]) -> Dict[str, Any]:
    malicious = stats.get("malicious", 0)
    suspicious = stats.get("suspicious", 0)
    engines = sum(stats.get(k, 0) for k in
                  ("malicious", "suspicious", "harmless", "undetected", "timeout"))
    if malicious > 0:
        level, label = "malicious", "Malicious"
    elif suspicious > 0:
        level, label = "suspicious", "Suspicious"
    elif engines > 0:
        level, label = "clean", "No engines flagged this"
    else:
        level, label = "unknown", "No verdict yet"
    return {
        "level": level,
        "label": label,
        "detections": malicious + suspicious,
        "engines": engines,
        "score": f"{malicious + suspicious}/{engines}" if engines else "—",
        "severity": _SEVERITY_ORDER[level],
    }


def _vendors(results: Dict[str, Any]) -> list:
    out = []
    for engine, r in (results or {}).items():
        if not isinstance(r, dict):
            continue
        out.append({
            "engine": r.get("engine_name") or engine,
            "category": r.get("category") or "undetected",
            "result": r.get("result") or None,
            "method": r.get("method") or "",
            "version": r.get("engine_version") or "",
            "updated": r.get("engine_update") or "",
        })
    # Flagged engines first, then alphabetical.
    rank = {"malicious": 0, "suspicious": 1, "timeout": 2,
            "type-unsupported": 4, "undetected": 3, "harmless": 3}
    out.sort(key=lambda v: (rank.get(v["category"], 5), v["engine"].lower()))
    return out


def normalize(kind: str, target: str, payload: dict) -> dict:
    """Turn a VT `data` object into the single shape the frontend consumes."""
    data = (payload or {}).get("data", {}) or {}
    attrs = data.get("attributes", {}) or {}

    if data.get("type") == "analysis":
        stats = attrs.get("stats", {}) or {}
        results = attrs.get("results", {}) or {}
        status = attrs.get("status", "queued")
    else:
        stats = attrs.get("last_analysis_stats", {}) or {}
        results = attrs.get("last_analysis_results", {}) or {}
        status = "completed"

    stats = {k: int(stats.get(k, 0) or 0)
             for k in ("malicious", "suspicious", "harmless", "undetected", "timeout")}

    meta: Dict[str, Any] = {"reputation": attrs.get("reputation")}
    if kind == "url":
        meta.update({
            "final_url": attrs.get("last_final_url"),
            "title": attrs.get("title"),
            "times_submitted": attrs.get("times_submitted"),
            "last_analysis_date": attrs.get("last_analysis_date"),
            "categories": attrs.get("categories") or {},
        })
        permalink = f"{GUI_BASE}/url/{url_identifier(target)}"
    elif kind == "file":
        meta.update({
            "names": (attrs.get("names") or [])[:5],
            "size": attrs.get("size"),
            "type_description": attrs.get("type_description"),
            "md5": attrs.get("md5"),
            "sha1": attrs.get("sha1"),
            "sha256": attrs.get("sha256"),
            "first_submission_date": attrs.get("first_submission_date"),
            "meaningful_name": attrs.get("meaningful_name"),
        })
        permalink = f"{GUI_BASE}/file/{attrs.get('sha256') or target}"
    elif kind == "ip":
        meta.update({
            "as_owner": attrs.get("as_owner"),
            "asn": attrs.get("asn"),
            "country": attrs.get("country"),
            "network": attrs.get("network"),
            "rir": attrs.get("regional_internet_registry"),
        })
        permalink = f"{GUI_BASE}/ip-address/{target}"
    else:  # domain
        meta.update({
            "registrar": attrs.get("registrar"),
            "creation_date": attrs.get("creation_date"),
            "categories": attrs.get("categories") or {},
            "dns": [
                {"type": r.get("type"), "value": r.get("value")}
                for r in (attrs.get("last_dns_records") or [])[:8]
            ],
        })
        permalink = f"{GUI_BASE}/domain/{target}"

    return {
        "ok": True,
        "kind": kind,
        "target": target,
        "status": status,
        "stats": stats,
        "verdict": _verdict(stats),
        "vendors": _vendors(results),
        "meta": {k: v for k, v in meta.items() if v not in (None, [], {}, "")},
        "permalink": permalink,
        "checked_at": int(time.time()),
    }
